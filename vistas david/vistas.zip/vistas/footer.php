<footer>
    <p>&copy; <?php echo date("Y");?> Mi Sitio Web. Todos los derechos reservados.</p>
</footer>
<script src="script.js"></script>
</body>
</html>
